/*global document, console, browser, alert, modSitesdb, confirm */
/*jslint laxcomma:true */
// jshint undef:true
// jshint eqeqeq:true
// jshint forin:true
// jshint latedef:true
// Create the non-site dictionary for appConfig

var mSites = modSitesdb();
function saveOptions(e, iDoneFn, iAlertB ) {
	var onStore = function() {
		if ( iAlertB === true ) {
			alert( 'options saved' );
		}
		iDoneFn( );
	};
	var onErrorB = function() {
		alert( 'error options NOT saved' );
	};
  e.preventDefault();
	var aObj = { scoutConfig: mSites.appConfig.store };
	var bPromise = browser.storage.local.set( aObj );
	bPromise.then(onStore, onErrorB);
}

document.querySelectorAll('input');
// document.addEventListener("DOMContentLoaded", restoreOptions);
document.querySelector("form").addEventListener("submit", function( e ) { saveOptions( e, function(){}, true ); } );
var setFields = function( config_fields ) {
	var bDiv, inx, divEl, val, field, nerdEl, nerdKeyS, nerdS,hEl,labelEl,inEl;
	bDiv = document.getElementById( 'addHere' );
//	bDiv.innerHTML = '';
	while (bDiv.firstChild) {
		bDiv.firstChild.remove();
	}
//	console.log( 'appConfig.store:' + JSON.stringify( appConfig.store ) );
	for ( inx in config_fields ) {
		if ( config_fields.hasOwnProperty( inx ) ) {
			field = config_fields[ inx ];
			divEl = document.createElement('div');
			bDiv.appendChild( divEl );
//			bS = '';
			if (( field.section !== undefined )&&( field.section !== '' )) {
//				bS += '<h3>' + field.section + '</h3>';
				hEl = document.createElement('h3');
				hEl.appendChild(document.createTextNode(field.section));
				divEl.appendChild( hEl );
			}
			labelEl = document.createElement('label');
//			bS += '<label>';
			if( mSites.appConfig.store[ inx ] !== undefined ) {
				val = mSites.appConfig.store[ inx ];
			} else {
//				alert( inx + ' undefined ' ); // after added extra site
				val = field.default;
			}
			inEl = document.createElement('input');
			if ( field.type === 'checkbox' ) {
				inEl.setAttribute( 'type', 'checkbox' );
				inEl.setAttribute( 'name', inx );
				inEl.setAttribute( 'value', '' );
//				bS += '<input type="checkbox" value="" name="' + inx + '" ';
				if ( val === true ) { 
					inEl.setAttribute( 'checked', 'checked' );
//					bS += ' checked '; 
				}
//				bS += '>';
//				bS += field.label;
				labelEl.appendChild( inEl );
				labelEl.appendChild(document.createTextNode(field.label));
			} else {
				inEl.setAttribute( 'type', 'text' );
				inEl.setAttribute( 'name', inx );
				inEl.setAttribute( 'value', val );
//				bS += field.label;
//				bS += '<input type="text" value="' + val + '" name="' + inx + '">';
				labelEl.appendChild(document.createTextNode(field.label));
				labelEl.appendChild( inEl );
			}
//			labelEl.appendChild(document.createTextNode(field.label));
//			bS += '</label>';
			divEl.appendChild( labelEl );
//			divEl.innerHTML = bS;
//			console.log( bS );
		}
	}
	var inputList = document.querySelectorAll('input');
	inputList.forEach( function( iEl, iN, iList ) {
		iEl.addEventListener( 'change', function( ) { 
			var val;
			if ( iEl.getAttribute( 'type' ) === 'checkbox' ) {
				val = ( iEl.checked === true );
			} else {
				val = iEl.value;
			}
//				console.log( 'set ' + iEl.name + ' to ' + val); 
			mSites.appConfig.store[ iEl.name ] = val;
			} );
		}
	);
	document.getElementById('sauceReset').addEventListener( 'click', function( e ) {
		if ( confirm( 'Reset settings to original state, does not effect sticky notes, or link cache' ) ){
			var configFldDefns = mSites.getConfigFldDefns( mSites );
			mSites.appConfig.store = mSites.makeDefaultConfig( configFldDefns );
			saveOptions( e, function() { setFields( mSites.getConfigFldDefns( mSites ) ); }, false );
		}
	} );
	document.getElementById('sauceNotesClear').addEventListener( 'click', function( e ) { 
		e.preventDefault();
		if ( confirm( 'delete all sticky notes' ) ) {
			mSites.appConfig.notes = {};
			mSites.appConfig.saveNotes( function() {} );
		}
	} );
	document.getElementById('sauceCacheClear').addEventListener( 'click', function( e ) { 
		e.preventDefault();
		if ( confirm( 'delete tracker link cache' ) ) {
			mSites.appConfig.imdbs = {};
			mSites.appConfig.saveImdbs( function() {} );
		}
	} );
	document.getElementById('idNerdData').addEventListener( 'change', function( e ) { 
		mSites.appConfig.store.nerdKeyS = e.target.value;
		saveOptions( e, function() { setFields( mSites.getConfigFldDefns( mSites ) ); }, false );
	} );
	document.getElementById('idNerdImport').addEventListener( 'click', function( e ) {
		var aJson,jsonS,textEl;
		var merge = function( iJson, iFldS ) {
			var inx;
			for ( inx in iJson ) {
				if ( iJson.hasOwnProperty( inx ) ) {
					mSites.appConfig[iFldS][inx] = iJson[inx];
				}
			}
		};
		e.preventDefault();
		textEl = document.getElementById('saucetextarea');
		jsonS = textEl.value;
		if ( jsonS === '' ) {
			alert( 'no data entered' );
		} else {
			try {
//				console.log( 'jsonS:' + jsonS );
				aJson = JSON.parse(jsonS);
//				console.log( 'parsed jsonS:' + jsonS );
			} catch(err) {
				alert( 'Entered JSON Error:' + err.message );
			}
			nerdKeyS = mSites.appConfig.store.nerdKeyS;
			if ( nerdKeyS === "1" ) {
				merge( aJson, 'notes' );
				mSites.appConfig.saveNotes( function() {} );
			} else if ( nerdKeyS === "2" ) {
				merge( aJson, 'imdbs' );
				mSites.appConfig.saveImdbs( function() {} );
			} else if ( nerdKeyS === "3" ) {
				mSites.appConfig.extrasites = aJson;
				mSites.appConfig.saveExtrasites( function() {} );
			} else if ( nerdKeyS === "0" ) {
				alert( 'json OK, no action selected' );
			}
		}
	} );
	nerdS = '';
	nerdKeyS = mSites.appConfig.store.nerdKeyS;
	if ( nerdKeyS !== undefined ) {
		document.getElementById('idNerdData').value = nerdKeyS;
	}
	if ( nerdKeyS === "1" ) {
		nerdS = JSON.stringify( mSites.appConfig.notes );
	} else if ( nerdKeyS === "2" ) {
		nerdS = JSON.stringify( mSites.appConfig.imdbs );
	} else if ( nerdKeyS === "3" ) {
		nerdS = JSON.stringify( mSites.appConfig.extrasites );
	} else if ( nerdKeyS === "4" ) {
		nerdS = 'spare';
	} else if ( nerdKeyS === "0" ) {
		nerdS = 'none';
	}
	nerdEl = document.getElementById('saucetextarea'); 
	nerdEl.value = nerdS;
};
mSites.setupConfig( mSites, function() { setFields( mSites.getConfigFldDefns( mSites ) ); } );

