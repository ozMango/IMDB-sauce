/*global browser, alert, $ */
/*jslint laxcomma:true */
// jshint undef:true
// jshint eqeqeq:true
// jshint forin:true
// jshint latedef:true
//------------------------------------------------------
// A list of all the sites, and the data necessary to
// check IMDb against them.
// Each site is a dictionary with the following attributes:
//  - name:
//      The site name, abbreviated
//  - searchUrl:
//      The URL to perform the search against, see below for how
//      to tailor the string to a site
//  - matchRegex:
//      The string which appears if the searchUrl *doesn't* return a result
//  - postiveMatch:
//      Changes the test to return true if the searchUrl *does* return
//      a result that matches matchRegex
//  - TV (optional):
//      If true, it means that this site will only show up on TV pages.
//      By default, sites only show up on movie pages.
//  - both (optional):
//      Means that the site will show up on both movie and TV pages
//  - spaceEncode (optional):
//      Changes the character used to encode spaces in movie titles
//      The default is '+'.
//  - goToUrl (optional):
//      Most of the time the same URLs that are used for checking are
//      the ones that are used to actually get to the movie,
//      but this allows overriding that.
//  - loggedOutRegex (optional):
//      If any text on the page matches this regex, the site is treated
//      as being logged out, rather than mising the movie. This option is
//      not effected by postiveMatch.
// To create a search URL, there are four parameters
// you can use inside the URL:
//  - %tt%:
//      The IMDb id with the tt prefix (e.g. tt0055630)
//  - %nott%:
//      The IMDb id without the tt prefix (e.g. 0055630)
//  - %search_string%:
//      The movie title (e.g. Yojimbo)
//  - %year%:
//      The movie year (e.g. 1961)
// See below for examples
//------------------------------------------------------
var modSitesdb = function( ) { 'use strict';
	var mod = {};
	var allSites;
	var sites = [
	{ 'name': 'ADC',
		'searchUrl': 'https://asiandvdclub.org/browse.php?descr=1&btnSubmit=Submit&search=%tt%',
		'matchRegex': /Your search returned zero results|<h1>You need cookies enabled to log in.<\/h1>/,
		'both': true},
	{ 'name': 'AHD',
		'searchUrl': 'https://awesome-hd.me/torrents.php?id=%tt%',
		'matchRegex': /Your search did not match anything.|<h2>Error 404<\/h2>/,
		'both': true},
	{ 'name': 'AR',
		'searchUrl': 'https://alpharatio.cc/torrents.php?searchstr=%search_string%+%year%&filter_cat[6]=1&filter_cat[7]=1&filter_cat[8]=1&filter_cat[9]=1',
		'matchRegex': /Your search did not match anything/},
	{ 'name': 'AR',
		'searchUrl': 'https://alpharatio.cc/torrents.php?searchstr=%search_string%&filter_cat[1]=1&filter_cat[2]=1&filter_cat[3]=1&filter_cat[4]=1&filter_cat[5]=1',
		'matchRegex': /Your search did not match anything/,
		'TV': true},
	{ 'name': 'AT',
		'searchUrl': 'https://avistaz.to/movies?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true},
	{ 'name': 'AT',
		'searchUrl': 'https://avistaz.to/tv-shows?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true,
		'TV': true},
	{ 'name': 'Blutopia',
		'searchUrl': 'https://blutopia.xyz/search?name=%search_string%',
		'both': true},
	{ 'name': 'bB',
		'searchUrl': 'https://baconbits.org/torrents.php?action=basic&filter_cat[9]=1&searchstr=%search_string%+%year%',
		'matchRegex': /Your search was way too l33t|You will be banned for 6 hours after your login attempts run out/},
	{ 'name': 'bB',
		'searchUrl': 'https://baconbits.org/torrents.php?action=basic&filter_cat[8]=1&filter_cat[10]=1&searchstr=%search_string%',
		'matchRegex': /Your search was way too l33t|You will be banned for 6 hours after your login attempts run out/,
		'TV': true},
	{ 'name': 'BB-HD',
		'searchUrl': 'https://bluebird-hd.org/browse.php?search=&incldead=0&cat=0&dsearch=%tt%&stype=or',
		'matchRegex': /Nothing found|Ничего не найдено/,
		'both': true},
	{ 'name': 'BHD',
		'searchUrl': 'https://beyondhd.xyz/browse.php?search=%tt%&searchin=title&incldead=1',
		'matchRegex': /Nothing found!|Please login or Register a personal account to access our user area and great community/},
	{ 'name': 'BHD',
		'searchUrl': 'https://beyondhd.xyz/browse.php?c40=1&c44=1&c48=1&c89=1&c46=1&c45=1&search=%search_string%&searchin=title&incldead=0',
		'matchRegex': /Nothing found!|Please login or Register a personal account to access our user area and great community/,
		'TV': true},
	{ 'name': 'BitHD',
		'searchUrl': 'http://www.bit-hdtv.com/torrents.php?cat=0&search=%tt%',
		'matchRegex': /<h2>No match!<\/h2>/},
	{ 'name': 'BitHQ',
		'searchUrl': 'http://www.bithq.org/search.php?search=%search_string%&options=AND&in=original&incldead=1',
		'matchRegex': /Try again with a refined search string|<h1>Not logged in!<\/h1>/},
	{ 'name': 'BMTV',
		'searchUrl': 'https://www.bitmetv.org/browse.php?search=%search_string%',
		'matchRegex': /Nothing found!<\/h2>/,
		'TV': true},
	{ 'name': 'BTN',
		'searchUrl': 'https://broadcasthe.net/torrents.php?imdb=%tt%',
		'matchRegex': /Error 404|Lost your password\?/,
		'TV': true},
	{ 'name': 'BTN-Req',
		'searchUrl':  'https://broadcasthe.net/requests.php?search=%search_string%',
		'matchRegex': /Nothing found|Lost your password\?/,
		'TV': true},
	{ 'name': 'CaCh',
		'searchUrl': 'http://www.cartoonchaos.org/index.php?page=torrents&search=%search_string%&category=0&options=0&active=0',
		'matchRegex': />Av.<\/td>\s*<\/tr>\s*<\/table>|not authorized to view the Torrents/,
		'both': true},
	{ 'name': 'CC',
		'searchUrl': 'http://www.cine-clasico.com/foros/search.php?terms=any&author=&sc=1&sf=all&sr=posts&sk=t&sd=d&st=0&ch=300&t=0&submit=Search&keywords=%tt%',
		'matchRegex': /You will be banned for 6 hours after your login attempts run out.|You must specify at least one word to search for. Each word must consist of at least 3 characters and must not contain more than 14 characters excluding wildcards.|Disculpe/},
	{ 'name': 'CG',
		'searchUrl': 'https://cinemageddon.net/browse.php?search=%tt%',
		'matchRegex': /<h2>Nothing found!<\/h2>/,
		'loggedOutRegex': 'Not logged in!'},
	{ 'name': 'CG-c',
		'searchUrl': 'https://cinemageddon.net/cocks/endoscope.php?what=imdb&q=%tt%',
		'matchRegex': /<h2>Nothing found!<\/h2>/,
		'loggedOutRegex': 'Not logged in!'},
	{ 'name': 'CHD',
		'searchUrl': 'https://chdbits.co/torrents.php?incldead=1&spstate=0&inclbookmarked=0&search_area=4&search_mode=0&search=%tt%',
		'matchRegex': /Nothing found/},
	{ 'name': 'Classix',
		'searchUrl': 'http://classix-unlimited.co.uk/torrents-search.php?search=%search_string%',
		'matchRegex': /Nothing Found<\/div>/},
	{ 'name': 'Demnoid',
		'searchUrl': 'http://www.demonoid.pw/files/?query=%tt%',
		'matchRegex': /<b>No torrents found<\/b>|We are currently performing the daily site maintenance.<br>/,
		'both': true},
	{ 'name': 'DVDSeed',
		'searchUrl': 'http://www.dvdseed.eu/browse2.php?search=%tt%&wheresearch=2&incldead=1&polish=0&nuke=0&rodzaj=0',
		'matchRegex': /Nic tutaj nie ma!<\/h2>/},
	{ 'name': 'ET',
		'searchUrl': 'https://cinemaz.to/movies?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true},
	{ 'name': 'ET',
		'searchUrl': 'https://cinemaz.to/tv-shows?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true,
		'TV': true},
	{ 'name': 'eThor',
		'searchUrl': 'http://ethor.net/browse.php?stype=b&c23=1&c20=1&c42=1&c5=1&c19=1&c25=1&c6=1&c37=1&c43=1&c7=1&c9=1&advcat=0&incldead=0&includedesc=1&search=%tt%',
		'matchRegex': /Try again with a refined search string.|<h1>Note: Vous devez activer vos 'cookies' pour pouvoir vous identifier.<\/h1>/},
	{ 'name': 'ExtraTorrent',
		'searchUrl': 'https://extratorrent.cc/search/?search=%search_string%+%year%',
		'matchRegex': /total <b>0<\/b> torrents found/},
	{ 'name': 'FL',
		'searchUrl': 'https://filelist.ro/browse.php?search=%tt%',
		'matchRegex': /<h2>Nu s-a găsit nimic!<\/h2>/,
		'both': true},
	{ 'name': 'FSS',
		'searchUrl': 'http://fss.omnilounge.co.uk/browse.php?blah=2&cat=0&incldead=1&search=%tt%',
		'matchRegex': /Try again with a different search string?|<h1>You need cookies enabled to log in.<\/h1>/},
	{ 'name': 'GFT',
		'searchUrl': 'https://www.thegft.org/browse.php?view=0&c2=1&c1=1&c9=1&c11=1&c48=1&c8=1&c18=1&c49=1&c7=1&c38=1&c46=1&c5=1&c13=1&c26=1&c37=1&c19=1&c47=1&c17=1&c4=1&c22=1&c25=1&c20=1&c3=1&search=%tt%&searchtype=0',
		'matchRegex': /Nothing found!<\/h2>/},
	{ 'name': 'GFT',
		'searchUrl': 'https://www.thegft.org/browse.php?view=0&search=%search_string%',
		'matchRegex': /Nothing found!<\/h2>/,
		'TV': true},
	{ 'name': 'GFT-Gems',
		'searchUrl': 'https://www.thegft.org/browse.php?view=1&search=%tt%&searchtype=0',
		'matchRegex': /Nothing found!<\/h2>/},
	{ 'name': 'HD',
		'searchUrl': 'http://hounddawgs.org/torrents.php?type=&userid=&searchstr=&searchimdb=%tt%&searchlang=&searchtags=&order_by=s3&order_way=desc&showOnly=#results',
		'matchRegex': /<h2>Din søgning gav intet resultat.<\/h2>/,
		'both': true},
	{ 'name': 'HDb',
		'searchUrl': 'https://hdbits.org/browse.php?c3=1&c1=1&c4=1&c2=1&imdb=%tt%',
		'matchRegex': /Nothing here!|You need cookies enabled to log in/,
		'both': true},
	{ 'name': 'HDC',
		'searchUrl': 'https://hdchina.club/torrents.php?incldead=0&spstate=0&inclbookmarked=0&boardid=0&seeders=&search=%tt%&search_area=4&search_mode=2',
		'matchRegex': /Nothing found! Try again with a refined search string./},
	{ 'name': 'HDClub',
		'searchUrl': 'http://hdclub.org/browse.php?webdl=0&3d=0&search=&incldead=0&dsearch=%tt%',
		'matchRegex': /Nothing was found|Ничего не найдено|Нічого не знайдено/,
		'both': true},
	{ 'name': 'HDME',
		'searchUrl': 'https://hdme.eu/browse.php?blah=2&cat=0&incldead=1&search=%tt%',
		'matchRegex': /Try again with a refined search string.|<h1>You need cookies enabled to log in.<\/h1>/},
	{ 'name': 'HDME',
		'searchUrl': 'https://hdme.eu/browse.php?search=%search_string%&blah=0&cat=0&incldead=1',
		'matchRegex': /Try again with a refined search string.|<h1>You need cookies enabled to log in.<\/h1>/,
		'TV': true},
	{ 'name': 'HDS',
		'searchUrl': 'https://hdsky.me/torrents.php?incldead=1&search=%tt%&search_area=4&search_mode=0',
		'matchRegex': /Nothing found! Try again with a refined search string|Email:hdsky.me@gmail.com/},
	{ 'name': 'HDS',
		'searchUrl': 'https://hdsky.me/torrents.php?cat402=1&cat403=1&incldead=1&search=%search_string%&search_area=0&search_mode=0',
		'matchRegex': /Nothing found! Try again with a refined search string|Email:hdsky.me@gmail.com/,
		'TV': true},
	{ 'name': 'HDSpace',
		'icon': 'http://www.favicon.by/ico/5991df36e3635.ico',
		'searchUrl': 'https://hd-space.org/index.php?page=torrents&active=0&options=2&search=%nott%',
		'both': true},
	{ 'name': 'HDT',
		'icon': 'https://hdts.ru/favicon.ico',
		'searchUrl': 'http://hd-torrents.org/torrents.php?active=0&options=2&search=%tt%',
		'matchRegex': /No torrents here.../,
		'both': true},
	{ 'name': 'HDVN',
		'searchUrl': 'http://torviet.com/torrents.php?search=%tt%&search_area=4&search_mode=0',
		'matchRegex': /Nothing found! Try again with a refined search string|You need cookies enabled to log in or switch language/,
		'both': true},
	{ 'name': 'ILC',
		'searchUrl': 'http://www.iloveclassics.com/browse.php?incldead=1&searchin=2&search=%tt%',
		'matchRegex': /Try again with a refined search string|<h1>Not logged in!<\/h1>/},
	{ 'name': 'IPT',
		'searchUrl': 'https://www.iptorrents.com/torrents/?q=%tt%',
		'matchRegex': /<h1 style="color:yellow">No Torrents Found!/},
	{ 'name': 'IPT',
		'searchUrl': 'https://www.iptorrents.com/torrents/?q=%search_string%',
		'matchRegex': /<h1 style="color:yellow">No Torrents Found!/,
		'TV': true},
	{ 'name': 'KG',
		'searchUrl': 'https://karagarga.in/browse.php?search_type=imdb&search=%nott%',
		'matchRegex': /<h2>No torrents found|<h1>If you want the love<\/h1>/},
	{ 'name': 'KZ',
		'searchUrl': 'http://kinozal.tv/browse.php?s=%search_string%+%year%&g=0&c=1002&v=0&d=0&w=0&t=0&f=0',
		'matchRegex': 'Нет активных раздач, приносим извинения. Пожалуйста, уточните параметры поиска'},
	{ 'name': 'KZ',
		'searchUrl': 'http://kinozal.tv/browse.php?s=%search_string%+%year%&g=0&c=1001&v=0&d=0&w=0&t=0&f=0',
		'matchRegex': 'Нет активных раздач, приносим извинения. Пожалуйста, уточните параметры поиска',
		'TV': true},
	{ 'name': 'M-T',
		'searchUrl': 'https://tp.m-team.cc/movie.php?incldead=1&spstate=0&inclbookmarked=0&search=%tt%&search_area=4&search_mode=2',
		'matchRegex': /Nothing here!|Try again with a refined search string./},
	{ 'name': 'MS',
		'searchUrl': 'http://www.myspleen.org/browse.php?search=%search_string%&title=0&cat=0',
		'matchRegex': /<strong>Nothing found!<\/strong>|<title>MySpleen :: Login<\/title>/,
		'both': true},
	{ 'name': 'MTV',
		'searchUrl': 'https://www.morethan.tv/torrents.php?searchstr=%search_string%+%year%&tags_type=1&order_by=time&order_way=desc&group_results=1&filter_cat%5B1%5D=1&action=basic&searchsubmit=1',
		'matchRegex': /<h2>Your search did not match anything.<\/h2>/},
	{ 'name': 'MTV',
		'searchUrl': 'https://www.morethan.tv/torrents.php?searchstr=%search_string%&tags_type=1&order_by=time&order_way=desc&group_results=1&filter_cat%5B2%5D=1&action=basic&searchsubmit=1',
		'matchRegex': /<h2>Your search did not match anything.<\/h2>/,
		'TV': true},
	{ 'name': 'NNM',
		'searchUrl': 'https://nnm-club.me/forum/tracker.php?nm=%search_string%+%year%',
		'matchRegex': 'Не найдено',
		'both': true},
	{ 'name': 'NB',
		'searchUrl': 'https://norbits.net/browse.php?incldead=1&fullsearch=0&scenerelease=0&imdbsearch=%tt%&imdb_from=0&imdb_to=0&search=',
		'matchRegex': /<h3>Ingenting her!<\/h3>/,
		'both': true},
	{ 'name': 'NBL',
		'searchUrl': 'https://nebulance.io/torrents.php?order_by=time&order_way=desc&searchtext=%search_string%&search_type=0&taglist=&tags_type=0',
		'matchRegex': /Your search did not match anything/,
		'TV': true},
	{ 'name': 'PHD',
		'searchUrl': 'https://privatehd.to/movies?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true},
	{ 'name': 'PHD',
		'searchUrl': 'https://privatehd.to/tv-shows?search=&imdb=%tt%',
		'matchRegex': /class="overlay-container"/,
		'positiveMatch': true,
		'TV': true},
	{ 'name': 'PTN',
		'icon': 'https://piratethenet.org/pic/favicon.ico',
		'searchUrl': 'https://piratethenet.org/browseold.php?incldead=1&_by=3&search=%tt%',
		'matchRegex': /Nothing found!/,
		'both': true},
	{ 'name': 'PTP',
		'searchUrl': 'https://passthepopcorn.me/torrents.php?imdb=%tt%',
		'matchRegex': /<h2>Your search did not match anything.<\/h2>/},
	{ 'name': 'PTP-Req',
		'searchUrl': 'https://passthepopcorn.me/requests.php?submit=true&search=%tt%',
		'matchRegex': /Your search did not match anything.|<h1>Keep me logged in.<\/h1>/},
	{ 'name': 'PxHD',
		'searchUrl': 'https://pixelhd.me/torrents.php?groupname=&year=&tmdbover=&tmdbunder=&tmdbid=&imdbover=&imdbunder=&imdbid=%tt%&order_by=time&order_way=desc&taglist=&tags_type=1&filterTorrentsButton=Filter+Torrents',
		'matchRegex': /<h2>Your search did not match anything.<\/h2>/},
	{ 'name': 'RARAT',
		'searchUrl': 'https://rarat.org/api/v1/torrents?extendedSearch=false&hideOld=false&index=0&limit=15&order=asc&page=search&searchText=%tt%&sort=n#https://rarat.org/search?search=%tt%',
		'goToUrl': 'https://rarat.org/search?search=%tt%',
		'matchRegex': /^$/,
		'both': true},
	{ 'name': 'RARBG',
		'searchUrl': 'https://rarbg.to/torrents.php?imdb=%tt%',
		'matchRegex': '//dyncdn.me/static/20/images/imdb_thumb.gif',
		'positiveMatch': true,
		'both': true},
	{ 'name': 'RevTT',
		'searchUrl': 'https://www.revolutiontt.me/browse.php?search=%tt%',
		'matchRegex': /<h2>Nothing found!<\/h2>/},
	{ 'name': 'RevTT',
		'searchUrl': 'https://www.revolutiontt.me/browse.php?search=%search_string%&cat=0&incldead=1&titleonly=1',
		'matchRegex': /<h2>Nothing found!<\/h2>/,
		'TV': true},
	{ 'name': 'RuT',
		'searchUrl': 'https://rutracker.org/forum/tracker.php?nm=%search_string%',
		'matchRegex': 'Не найдено',
		'both': true},
	{ 'name': 'Rutor',
		'searchUrl': 'http://rutor.info/search/0/0/010/0/%tt%',
		'matchRegex': 'Результатов поиска 0',
		'both': true},
	{ 'name': 'SC',
		'searchUrl': 'http://www.secret-cinema.net/browse.php?search=%search_string%',
		'matchRegex': /Try again with a refined search string\.|There was a problem executing the query/,
		'both': true},
	{ 'name': 'SC-F',
		'searchUrl': 'http://www.secret-cinema.net/search.php?action=search&show_as=topics&keywords=%tt%',
		'matchRegex': /Your search returned no hits\.|You do not have permission to view these forums\./,
		'both': true},
	{ 'name': 'SDBits',
		'searchUrl': 'http://sdbits.org/browse.php?c6=1&c3=1&c1=1&c4=1&c5=1&c2=1&m1=1&incldead=0&from=&to=&imdbgt=0&imdblt=10&uppedby=&imdb=&search=%tt%',
		'matchRegex': /Nothing found!|<h1>You need cookies enabled to log in.<\/h1>/},
	{ 'name': 'sHD',
		'searchUrl': 'https://scenehd.org/browse.php?search=%tt%',
		'matchRegex': /<h2>No torrents found!<\/h2>/},
	{ 'name': 'SM',
		'searchUrl': 'https://surrealmoviez.info/search.php?stext=%tt%',
		'matchRegex': /0 Movies found matching search criteria|You need to be logged in to view this page/},
	{ 'name': 'TBD',
		'icon': 'https://1.bp.blogspot.com/-F2JeKtPCJYI/VgjpVxwMO4I/AAAAAAAAADg/VyNyp-yW9Ac/s1600/TBD.ico',
		'searchUrl': 'http://www.torrentbd.com/torrent/torrents-search.php?search=%search_string%',
		'matchRegex': /No torrents were found based on your search criteria./,
		'both': true},
	{ 'name': 'TD',
		'searchUrl': 'https://www.torrentday.com/browse.php?search=%search_string%&cata=yes&c29=1&c30=1&c25=1&c11=1&c5=1&c3=1&c21=1&c22=1&c13=1&c44=1&c1=1&c24=1&c32=1&c31=1&c33=1&c46=1&c14=1&c26=1&c7=1&c2=1',
		'matchRegex': /Nothing found!/,
		'both': true},
	{ 'name': 'TE',
		'searchUrl': 'http://theempire.bz/browse.php?incldead=0&country=&nonboolean=1&search=%tt%',
		'matchRegex': /Try again with a refined search string|<h1>You need cookies enabled to log in.<\/h1>/,
		'both': true},
	{ 'name': 'TehC',
		'searchUrl': 'https://tehconnection.eu/torrents.php?action=basic&searchstr=%tt%',
		'matchRegex': /You will be banned for 6 hours after your login attempts run out.|<h2>No Search Results, try reducing your search options./},
	{ 'name': 'TG',
		'searchUrl': 'https://thegeeks.bz/browse.php?incldead=0&country=&nonboolean=1&search=%tt%',
		'matchRegex': /Try again with a refined search string|<h1>You need cookies enabled to log in.<\/h1>/,
		'both': true},
	{ 'name': 'THC', 
		'searchUrl': 'https://horrorcharnel.org/browse.php?search=%tt%&cat=0&incldead=1',
		'matchRegex': /<h1>Not logged in!<\/h1>|<h2>Nothing found!<\/h2>/},
	{ 'name': 'Tik',
		'searchUrl': 'http://cinematik.net/browse.php?srchdtls=1&incldead=1&search=%tt%',
		'matchRegex': /The page you tried to view can only be used when you're logged in|<h2>Nothing found!<\/h2>/},
	{ 'name': 'TL',
		'searchUrl': 'http://www.torrentleech.org/torrents/browse/index/query/%search_string%+%year%/categories/1,8,9,10,11,12,13,14,15,29',
		'matchRegex': /Signup With Invite|Please refine your search./},
	{ 'name': 'TL',
		'searchUrl': 'http://www.torrentleech.org/torrents/browse/index/query/%search_string%/categories/2,26,27,32',
		'matchRegex': /Signup With Invite|Please refine your search./,
		'TV': true},
	{ 'name': 'TPB',
		'searchUrl': 'https://thepiratebay.org/search/%tt%',
		'matchRegex': /No hits. Try adding an asterisk in you search phrase.<\/h2>/,
		'both': true},
	{ 'name': 'TVV',
		'searchUrl': 'http://tv-vault.me/torrents.php?searchstr=%search_string%',
		'matchRegex': /Nothing found<\/h2>/,
		'TV': true},
	{ 'name': 'UHDB',
		'searchUrl': 'https://uhdbits.org/torrents.php?action=advanced&groupname=%tt%',
		'matchRegex': /Your search did not match anything./},
	{ 'name': 'x264',
		'searchUrl': 'http://x264.me/browse.php?incldead=0&xtype=0&stype=3&search=%tt%',
		'matchRegex': /Try again with a refined search string.|<h1>Forgot your password?<\/h1>/}
	];
	var icon_sites = [
	{ 'name': 'OpenSubtitles',
		'searchUrl': 'http://www.opensubtitles.org/en/search/imdbid-%tt%'},
	{ 'name': 'YouTube.com',
		'searchUrl': 'https://www.youtube.com/results?search_query="%search_string%"+%year%+trailer'},
	{ 'name': 'Rotten Tomatoes',
		'searchUrl': 'https://www.rottentomatoes.com/search/?search=%search_string%'},
	{ 'name': 'Criticker',
		'searchUrl': 'https://www.criticker.com/?search=%search_string%&type=films'},
	{ 'name': 'iCheckMovies',
		'searchUrl': 'https://www.icheckmovies.com/search/movies/?query=%tt%'},
	{ 'name': 'Letterboxd',
		'searchUrl': 'http://letterboxd.com/imdb/%nott%'},
	{ 'name': 'Subscene',
		'searchUrl': 'http://subscene.com/subtitles/title?q=%search_string%'},
	{ 'name': 'SubtitleSeeker',
		'searchUrl': 'http://www.subtitleseeker.com/%nott%/Movie/Releases/English/'},
	{ 'name': 'Wikipedia',
		'searchUrl': 'https://en.wikipedia.org/w/index.php?search=%search_string%&go=Go'},
	{ 'name': 'FilmAffinity',
		'searchUrl': 'http://www.filmaffinity.com/en/advsearch.php?stext=%search_string%&stype[]=title&fromyear=%year%&toyear=%year%',
		'showByDefault': false},
	{ 'name': 'Metacritic',
		'searchUrl': 'http://www.metacritic.com/search/all/%search_string%/results?cats[movie]=1&cats[tv]=1&search_type=advanced&sort=relevancy',
		'showByDefault': false},
	{ 'name': 'Can I Stream.It? (Movie)',
		'searchUrl': 'http://www.canistream.it/search/movie/%search_string%',
		'showByDefault': false},
	{ 'name': 'Can I Stream.It? (TV)',
		'searchUrl': 'http://www.canistream.it/search/tv/%search_string%',
		'showByDefault': false},
	{ 'name': 'AllMovie',
		'searchUrl': 'http://www.allmovie.com/search/movies/%search_string%',
		'showByDefault': false},
	{ 'name': 'Facebook',
		'searchUrl': 'https://www.facebook.com/search/str/%search_string%/keywords_pages',
		'showByDefault': false},
	{ 'name': 'Amazon',
		'searchUrl': 'http://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Dmovies-tv&field-keywords=%search_string%',
		'showByDefault': false},
	{ 'name': 'Netflix',
		'searchUrl': 'http://www.netflix.com/search/%search_string%',
		'showByDefault': false},
	{ 'name': 'Blu-ray.com',
		'searchUrl': 'http://www.blu-ray.com/search/?quicksearch=1&quicksearch_country=all&quicksearch_keyword=%search_string%+&section=bluraymovies',
		'showByDefault': false},
	{ 'name': 'trakt.tv',
		'icon': 'https://walter.trakt.tv/hotlink-ok/public/favicon.ico',
		'searchUrl': 'https://trakt.tv/search?query=%search_string%',
		'showByDefault': false}
	];
	var getConfigFldDefns = function( iMod ) {
		// non site specific fields
		var configFldDefns = {
		'imdbscout_header_text': {
			'label': 'Header text:',
			'type': 'text',
			'default': 'Pirate this film: '
			},
		'sticky_notes': {
			'type': 'checkbox',
			'label': 'Store note on titles',
			'default': true
			},
		'enhance_torrent_pages': {
			'type': 'checkbox',
			'label': 'Enhance torrent site pages',
			'default': true
			},
		'enhance_all_pages': {
			'type': 'checkbox',
			'label': 'Enhance all pages',
			'default': false
			},
		'call_http': {
			'section': 'Page Options:',
			'type': 'checkbox',
			'label': 'Actually check for torrents?',
			'default': true
			},
		'hide_missing': {
			'type': 'checkbox',
			'label': 'Hide missing links?',
			'default': false
			},
		'use_icons': {
			'type': 'checkbox',
			'label': 'Use icons instead of text?',
			'default': false
			}
		};
		var index,icon_site,site;
		// Add each site to a appConfig dictionary schema
		// The appConfig default for checkboxes is false
		for ( index=0; (site=iMod.sites[index])!==undefined; index++ ) {
			configFldDefns['show_' + site.name + (site.TV ? '_TV' : '')] = {
			'section': (index === 0) ? ['Torrents:'] : '',
			'type': 'checkbox',
			'label': ' ' + site.name + (site.TV ? ' (TV)' : '')
			};
		}
		// Icon sites should be shown by default though,
		// since they barely use any resources.
		// $.each(icon_sites, function(index, icon_site) {
		for ( index=0; (icon_site=icon_sites[index])!==undefined; index++ ) {
			configFldDefns['show_icon_' + icon_site.name] = {
			'section': (index === 0) ? ['Other sites:'] : '',
			'type': 'checkbox',
			'label': ' ' + icon_site.name,
			'default': ('showByDefault' in icon_site) ?
				icon_site.showByDefault : true
			};
		}
		return configFldDefns;
	};
	var appConfig = {
		store: {}, // config stuff
		imdbs: {}, // cache of results indexed by movieId, per imdb movie Id
		notes: {}, // notes, per imdb movie Id
		extrasites: {}, // user supplied sites 
		get:function( iKey ) {
			return this.store[iKey];
		},
		saveImdbs:function( iFn ) {
			var onStore = function() {
				iFn();
			};
			var onErrorB = function() {
				alert( 'error imdbs NOT saved' );
			};
			var aObj = { imdbs: this.imdbs };
			var bPromise = browser.storage.local.set( aObj );
			bPromise.then(onStore, onErrorB);
		},
		saveNotes:function( iFn ) {
			var onStore = function() {
				iFn();
			};
			var onErrorB = function() {
				alert( 'error notes NOT saved' );
			};
			var aObj = { notes: this.notes };
			var bPromise = browser.storage.local.set( aObj );
			bPromise.then(onStore, onErrorB);
		},
		saveExtrasites:function( iFn ) {
			var onStore = function() {
				iFn();
			};
			var onErrorB = function() {
				alert( 'error extrasites NOT saved' );
			};
			var aObj = { extrasites: this.extrasites };
			var bPromise = browser.storage.local.set( aObj );
			bPromise.then(onStore, onErrorB);
		}
	};
	var makeDefaultConfig = function( iConfigFields ) {
		var config = {}, inx, fld;
		for ( inx in iConfigFields ) {
			if ( iConfigFields.hasOwnProperty( inx ) ) {
				fld = iConfigFields[ inx ];
				if ( fld.default !== undefined ) {
					config[inx] = fld.default;
				} else {
					config[inx] = false;
				}
			}
		}
		return config;
	};
	var setShowAsPerConfig = function( iMod ) {
		// Fetch per-site values from mSites.appConfig
		var j,site,icon_site;
		for ( j=0; (site=iMod.sites[j])!==undefined; j++ ) {
			site.show = appConfig.get('show_' + site.name + (site.TV ? '_TV' : ''));
		}
		for ( j=0; (icon_site=icon_sites[j])!==undefined; j++ ) {
			icon_site.show = appConfig.get('show_icon_' + icon_site.name);
		}
	};
	var mergeExtrasites = function( ) {
		var j, k, extraSite, nxSite, matchB;
		var mergedSites = sites.slice( 0 );
		for ( j=0; (extraSite=appConfig.extrasites[j])!==undefined; j++ ) {
			matchB = false;
			for ( k=0; (nxSite=mergedSites[j])!==undefined; j++ ) {
				if ( nxSite.name === extraSite.name ) {
					mergedSites[j] = extraSite;
					matchB = true;
				}
			}
			if ( matchB === false ) {
				mergedSites.push( extraSite );
			}
		}
		return mergedSites;
	};
	var setupConfig = function( iMod, iFn ) {
		function onGot(item) { // data from local store
			var configFldDefns, inx;
	//		alert( 'configuration found:' + JSON.stringify(item)  );
			if ( item.scoutConfig === undefined ) { // first use set config to default
				configFldDefns = getConfigFldDefns( iMod );
	//			alert( 'no scoutConfig' );
				appConfig.store = makeDefaultConfig( configFldDefns );
				// save config to local store, continue on success
				var aObj = { scoutConfig: appConfig.store, imdbs:{}, notes:{}, extrasites:[] };
				var bPromise = browser.storage.local.set( aObj );
				iMod.sites = sites;
				bPromise.then(onStore, onErrorB);
			} else {
				// set config from local store
				appConfig.store = item.scoutConfig;
				// set torrent site link info cache from local store
				if ( item.imdbs !== undefined ) {
					appConfig.imdbs = item.imdbs;
				} else {
					appConfig.imdbs = {};
				}
				// set title notes from local store
				if ( item.notes !== undefined ) {
					appConfig.notes = item.notes;
				} else {
					appConfig.notes = {};
				}
				if ( item.extrasites !== undefined ) {
					appConfig.extrasites = item.extrasites;
				} else {
					appConfig.extrasites = [];
				}
				iMod.sites = mergeExtrasites();
				setShowAsPerConfig( iMod ); // set 'show' in sites database
				iFn( ); // continue
			}
		}
		function onStore(item) {
			setShowAsPerConfig( iMod );
			iFn();
		}
		function onErrorB(error) {
			alert( 'onErrorB:' + error );
		}
		function onError(error) {
			alert( 'configuration not found:' + error );
		}
		var aPromise = browser.storage.local.get( ['scoutConfig','imdbs','notes','extrasites'] );
		aPromise.then(onGot, onError);
	};
	mod.sites = sites;
	mod.makeDefaultConfig = makeDefaultConfig;
	mod.icon_sites = icon_sites;
	mod.appConfig = appConfig;
	mod.setupConfig = setupConfig;
	mod.getConfigFldDefns = getConfigFldDefns;
	return mod;
};
